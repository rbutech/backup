package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.GenericServlet;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import weblogic.wtc.jatmi.ReqMsg;

public class RegFormServlet extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		int id = 0;
		String name = null;
		String email = null;
		String address = null;
		try {
			id = Integer.parseInt(req.getParameter("id"));
			name = req.getParameter("name");
			email = req.getParameter("email");
			address = req.getParameter("address");

		} catch (Exception e) {
			out.println("<font color='red'><h1>Please ENter valid data</h1></font>");
		}

		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "system", "manager");
			PreparedStatement pst = con
					.prepareStatement("insert into student values(?,?,?,?)");
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setString(3, email);
			pst.setString(4, address);
			int i = pst.executeUpdate();

			if (i != 0)
				out.println("<font color='green'><h1>Reg Success:) </h1></font>");
			else
				out.println("<font color='red'><h1>Reg Fail:(</h1></font>");
		} catch (Exception e) {
			out.println("<font color='red'><h1>" + e.getMessage()
					+ ":(</h1></font>");
		}

	}
}
