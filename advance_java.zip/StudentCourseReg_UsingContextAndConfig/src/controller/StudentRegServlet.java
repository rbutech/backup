package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StudentRegServlet extends GenericServlet {

	private Connection con;

	@Override
	public void init(ServletConfig config) throws ServletException {
		ServletContext scxt = config.getServletContext();
		String driver = scxt.getInitParameter("driver");
		String url = scxt.getInitParameter("url");
		String username = config.getInitParameter("username");
		String password = config.getInitParameter("password");
		System.out.println("Student User="+username);
		System.out.println("Student Password="+password);
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
		}
	}

	@Override
	public void service(ServletRequest req, ServletResponse res)
			throws ServletException, IOException {
			PrintWriter out=res.getWriter();
		
		
		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		try {
			PreparedStatement pst = con
					.prepareStatement("insert into student values(?,?,?)");
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setString(3, email);
			int i=pst.executeUpdate();
		if(i!=0)
			out.println("Student Reg success :)");
		else
			out.println("Student Reg  fail :(");
		} catch (Exception e) {
			out.println("Student Reg  fail :("+e.getMessage());
		}

	}
	
	@Override
	public void destroy() {
	try{
		con.close();
		
	}catch(Exception e){}
	}

}
