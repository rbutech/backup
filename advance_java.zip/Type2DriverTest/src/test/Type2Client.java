package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Types;

public class Type2Client {
	public static void main(String[] args) throws Exception {
		// Class.forName("oracle.jdbc.driver.OracleDriver");
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con = DriverManager.getConnection(
				"jdbc:oracle:oci:@localhost:1521:xe", "system", "manager");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from student007");
		ResultSetMetaData metaData = rs.getMetaData();
		int noofcolumns = metaData.getColumnCount();
		System.out.println(noofcolumns);
		for (int i = 1; i <= 4; i++) {
			String columnname = metaData.getColumnName(i);
			String datatype = metaData.getColumnTypeName(i);
			System.out.println("column:NO=" + i + ",Column:Name=" + columnname
					+ ",dataType=" + datatype);
		}
		while (rs.next()) {
			System.out.println(rs.getInt("ID"));
			System.out.println(rs.getString("ADDRESS"));
			System.out.println(rs.getString("EMAIl"));
			System.out.println(rs.getString("NAME"));
		}

	}
}
