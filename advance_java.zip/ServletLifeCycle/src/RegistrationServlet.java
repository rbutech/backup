import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class RegistrationServlet implements Servlet {

	public RegistrationServlet() {
	System.out.println("RegistrationServlet object created");
	}
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("While After immediate Object creation ");

	}

	@Override
	public void service(ServletRequest arg0, ServletResponse arg1)
			throws ServletException, IOException {
				System.out.println("At user request");
	}
	@Override
	public void destroy() {
			System.out.println("At the undeployement or shattdown");

	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}


}
