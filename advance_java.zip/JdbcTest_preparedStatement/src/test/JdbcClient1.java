package test;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;
import java.util.Scanner;

public class JdbcClient1 {
	public static void main(String[] args) throws Exception {

		Properties properties = new Properties();
		properties
				.load(new FileInputStream(
						"E:/advance_java/JdbcTest_preparedStatement/src/resources/DB.properties"));

		Class.forName(properties.getProperty("driver"));
		Connection con = DriverManager.getConnection(
				properties.getProperty("url"), properties);

	PreparedStatement pstm=con.prepareStatement("delete from student where id=?");
	
	Scanner sc=new Scanner(System.in);
	
	while(true)
	{
		System.out.println("Enter ID=");
		int id=sc.nextInt();
		pstm.setInt(1, id);
		int i=pstm.executeUpdate();
		
		System.out.println("To Delete More Records Enter 1 else 2");
		
		int userinput=sc.nextInt();
		if(userinput==1){}
		else
		{
				System.exit(0);
		}
		
		
	}
	
		
		
		
	}
}
