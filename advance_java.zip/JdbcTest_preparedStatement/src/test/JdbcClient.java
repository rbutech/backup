package test;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;
import java.util.Scanner;

public class JdbcClient {
	public static void main(String[] args) throws Exception {

		Properties properties = new Properties();
		properties
				.load(new FileInputStream(
						"E:/advance_java/JdbcTest_preparedStatement/src/resources/DB.properties"));

		Class.forName(properties.getProperty("driver"));
		Connection con = DriverManager.getConnection(
				properties.getProperty("url"), properties);

	PreparedStatement pstm=con.prepareStatement("insert into student values(?,?,?,?)");
	
	Scanner sc=new Scanner(System.in);
	
	while(true)
	{
		System.out.println("Enter ID=");
		int id=sc.nextInt();
		pstm.setInt(1,id);
		System.out.println("Enter Name=");
		String name=sc.next();
		pstm.setString(2,name);
		System.out.println("Enter Email=");
		String email=sc.next();
		pstm.setString(3,email);
		System.out.println("Enter Address=");
		String address=sc.next();
		pstm.setString(4,address);
		int i=pstm.executeUpdate();
		System.out.println("To Enter More Records Enter 1 else 2");
		
		int userinput=sc.nextInt();
		if(userinput==1){}
		else
		{
				System.exit(0);
		}
		
		
	}
	
		
		
		
	}
}
