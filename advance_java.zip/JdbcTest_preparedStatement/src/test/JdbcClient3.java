package test;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Scanner;

public class JdbcClient3 {
	public static void main(String[] args) throws Exception {

		Properties properties = new Properties();
		properties
				.load(new FileInputStream(
						"E:/advance_java/JdbcTest_preparedStatement/src/resources/DB.properties"));

		Class.forName(properties.getProperty("driver"));
		Connection con = DriverManager.getConnection(
				properties.getProperty("url"), properties);

	PreparedStatement pstm=con.prepareStatement("select * from student where id=?");
	
	Scanner sc=new Scanner(System.in);
	
	while(true)
	{
		System.out.println("Enter ID=");
		int id=sc.nextInt();
		pstm.setInt(1, id);
			ResultSet rs=pstm.executeQuery();
		while(rs.next())
		{
			System.out.println("ID="+rs.getInt(1));
			System.out.println("NAME="+rs.getString(2));
			System.out.println("EMAIL="+rs.getString(3));
			System.out.println("ADDRESS="+rs.getString(4));
		}
		
		
		
		System.out.println("To Select More Records Enter 1 else 2");
		
		int userinput=sc.nextInt();
		if(userinput==1){}
		else
		{
				System.exit(0);
		}
		
		
	}
	
		
		
		
	}
}
