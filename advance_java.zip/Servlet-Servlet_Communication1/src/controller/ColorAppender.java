package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ColorAppender extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		//by passing pattern
		//RequestDispatcher rd = req.getRequestDispatcher("next");
		//by passing ClassName
		RequestDispatcher rd = getServletContext().getNamedDispatcher(
				"HelloServlett");
		out.println("<body style='background-color:red;'>");
		rd.include(req, resp);
		out.println("</body>");
	}

}
