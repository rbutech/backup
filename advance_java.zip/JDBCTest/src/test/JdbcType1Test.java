package test;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

import sun.jdbc.odbc.JdbcOdbcDriver;

public class JdbcType1Test
{
	public static void main(String[] args)throws ClassNotFoundException,SQLException {
		
		//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Driver d=new JdbcOdbcDriver();
		DriverManager.registerDriver(d);
		Connection con=DriverManager.getConnection("jdbc:odbc:durgasoft_datasource", "system","manager");
		System.out.println(con);
		
		
	}

}
