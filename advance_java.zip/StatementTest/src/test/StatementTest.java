package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class StatementTest {
public static void main(String[] args)throws ClassNotFoundException,SQLException {
	//load
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	
	//get connection
	Connection con=DriverManager.getConnection("jdbc:odbc:durgasoft_datasource", "system","manager");
	//create statement
	Statement statement=con.createStatement();
	
	//create table
	String ddldrop="drop table student";
	String ddlcreate="create table student(id number,name varchar2(50),email varchar2(50))";
	statement.execute(ddldrop);
	statement.execute(ddlcreate);
	System.out.println("table created successfully");
	
	
}
}
