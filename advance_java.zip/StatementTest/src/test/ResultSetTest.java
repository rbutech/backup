package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultSetTest {
	public static void main(String[] args) throws ClassNotFoundException,
			SQLException {
		// load
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

		// get connection
		Connection con = DriverManager.getConnection(
				"jdbc:odbc:durgasoft_datasource", "system", "manager");
		con.setAutoCommit(false);// default it is true
		// create statement
		Statement statement = con.createStatement();

		String drl = "select * from student";

		ResultSet rs = statement.executeQuery(drl);

		while (rs.next()) {
			System.out.println("ID=" + rs.getInt(1));
			System.out.println("NAME=" + rs.getString(2));
			System.out.println("EMAIL=" + rs.getString(3));
		}

	}

}
