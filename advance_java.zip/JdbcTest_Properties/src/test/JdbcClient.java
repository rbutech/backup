package test;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class JdbcClient {
	public static void main(String[] args) throws Exception {

		Properties properties = new Properties();
		properties
				.load(new FileInputStream(
						"E:/advance_java/JdbcTest_Properties/src/resources/DB.properties"));

		System.out.println(properties.getProperty("user"));
		System.out.println(properties.getProperty("password"));

		Class.forName(properties.getProperty("driver"));
		Connection con = DriverManager.getConnection(
				properties.getProperty("url"), properties);

		System.out.println(con);

	}
}
