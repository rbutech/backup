package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CalController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
			PrintWriter out=resp.getWriter();
		String button = req.getParameter("submit");
		int fn=Integer.parseInt(req.getParameter("fn"));
		int sn=Integer.parseInt(req.getParameter("sn"));
		
		if (button.equals("add")||button.equals("&#3078;&#3105;&#3149;"))
		{
			out.println("Result="+(fn+sn));
		}
		if (button.equals("sub")||button.equals("&#3128;&#3116;&#3149;"))
		{
			out.println("Result="+(fn-sn));
		}
		if (button.equals("mul")||button.equals("&#3118;&#3137;&#3122;&#3149;"))
		{
			out.println("Result="+(fn*sn));
		}
		if (button.equals("div")||button.equals("&#3105;&#3135;&#3125;&#3149;"))
		{
			out.println("Result="+(fn/sn));
		}
	}
	
	
	

}
