package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ValidationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String address = req.getParameter("address");
		boolean b=false;
		if (name.equals("")) {
			out.println("Name is required");
		b=false;
		}
		if (email.equals("")) {
			out.println("Email is required");
			b=false;
		}
		if (address.equals("")) {
			out.println("Address is required");
			b=false;
			}
		else
		{
			b=true;
		}
		if(b==true)
		{
			System.out.println("Forword to Next");
			//for here we need to call next servlet
/*		RegistrationServlet servlet=(RegistrationServlet)getServletContext().getServlet("RegistrationServlet");
		servlet.doGet(req, resp);*/
			
		RequestDispatcher rd=req.getRequestDispatcher("/next");
		rd.forward(req, resp);
		}
		else
		{
			
		}
		
		
		
	}

}
