package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		System.out.println("Next Servlet Execution");
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String address = req.getParameter("address");
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "system", "manager");
			PreparedStatement ps = con
					.prepareStatement("insert into student values(?,?,?)");
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, address);
			int i = ps.executeUpdate();
			if (i != 0)
				out.println("success");
			else
				out.println("fail");
		} catch (Exception e) {
			out.println("fail");
		}

	}

}
