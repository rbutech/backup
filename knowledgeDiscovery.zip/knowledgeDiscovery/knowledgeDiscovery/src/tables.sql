create table doctor(did number primary key not null,dname varchar2(50),email varchar2(50),password varchar2(50),contact varchar2(30),address varchar2(100));

create table patient(pid number primary key,pname varchar2(30),age number,area varchar2(30),hypertention varchar2(30),daibetes varchar2(30),desease varchar2(30),username varchar2(30),password varchar2(30),did number references doctor(did))

create table defaults(did number primary key,dname varchar2(30),value varchar2(30));