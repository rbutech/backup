package Util;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Listner implements ServletContextListener {

	public void contextInitialized(ServletContextEvent sce) {
	Configuration cfg=new Configuration();
	cfg.configure();
	SessionFactory sf=cfg.buildSessionFactory();
		sce.getServletContext().setAttribute("sf", sf);
		
	}
	public void contextDestroyed(ServletContextEvent sce) {
		
		
	}
	
	
}
