package Util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConn {

private static Connection con;

public static Connection getConn(){
	
	try{
		Class.forName("oracle.jdbc.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","kd","kd");
		
	}catch(Exception e){}
	
return con; 
} 





}
