package beans;



/**
 * Patient entity. @author MyEclipse Persistence Tools
 */

public class Patient  implements java.io.Serializable {


    // Fields    

     private Integer pid;
     private Doctor doctor;
     private String pname;
     private Integer age;
     private String area;
     private String hypertention;
     private String daibetes;
     private String username;
     private String password;


    // Constructors

    /** default constructor */
    public Patient() {
    }

    
    /** full constructor */
    public Patient(Doctor doctor, String pname, Integer age, String area, String hypertention, String daibetes, String username, String password) {
        this.doctor = doctor;
        this.pname = pname;
        this.age = age;
        this.area = area;
        this.hypertention = hypertention;
        this.daibetes = daibetes;
        this.username = username;
        this.password = password;
    }

   
    // Property accessors

    public Integer getPid() {
        return this.pid;
    }
    
    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Doctor getDoctor() {
        return this.doctor;
    }
    
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public String getPname() {
        return this.pname;
    }
    
    public void setPname(String pname) {
        this.pname = pname;
    }

    public Integer getAge() {
        return this.age;
    }
    
    public void setAge(Integer age) {
        this.age = age;
    }

    public String getArea() {
        return this.area;
    }
    
    public void setArea(String area) {
        this.area = area;
    }

    public String getHypertention() {
        return this.hypertention;
    }
    
    public void setHypertention(String hypertention) {
        this.hypertention = hypertention;
    }

    public String getDaibetes() {
        return this.daibetes;
    }
    
    public void setDaibetes(String daibetes) {
        this.daibetes = daibetes;
    }

    public String getUsername() {
        return this.username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
   








}