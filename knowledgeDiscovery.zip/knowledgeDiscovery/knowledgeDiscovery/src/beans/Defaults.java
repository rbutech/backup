package beans;



/**
 * Defaults entity. @author MyEclipse Persistence Tools
 */

public class Defaults  implements java.io.Serializable {


    // Fields    

     private Integer did;
     private String dname;
     private String value;


    // Constructors

    /** default constructor */
    public Defaults() {
    }

    
    /** full constructor */
    public Defaults(String dname, String value) {
        this.dname = dname;
        this.value = value;
    }

   
    // Property accessors

    public Integer getDid() {
        return this.did;
    }
    
    public void setDid(Integer did) {
        this.did = did;
    }

    public String getDname() {
        return this.dname;
    }
    
    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getValue() {
        return this.value;
    }
    
    public void setValue(String value) {
        this.value = value;
    }
   








}