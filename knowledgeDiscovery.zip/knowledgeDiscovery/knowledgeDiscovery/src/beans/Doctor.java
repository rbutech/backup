package beans;

import java.util.HashSet;
import java.util.Set;


/**
 * Doctor entity. @author MyEclipse Persistence Tools
 */

public class Doctor  implements java.io.Serializable {


    // Fields    

     private Integer did;
     private String dname;
     private String email;
     private String password;
     private String contact;
     private String address;
     private Set patients = new HashSet(0);


    // Constructors

    /** default constructor */
    public Doctor() {
    }

    
    /** full constructor */
    public Doctor(String dname, String email, String password, String contact, String address, Set patients) {
        this.dname = dname;
        this.email = email;
        this.password = password;
        this.contact = contact;
        this.address = address;
        this.patients = patients;
    }

   
    // Property accessors

    public Integer getDid() {
        return this.did;
    }
    
    public void setDid(Integer did) {
        this.did = did;
    }

    public String getDname() {
        return this.dname;
    }
    
    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }

    public String getContact() {
        return this.contact;
    }
    
    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAddress() {
        return this.address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }

    public Set getPatients() {
        return this.patients;
    }
    
    public void setPatients(Set patients) {
        this.patients = patients;
    }
   








}