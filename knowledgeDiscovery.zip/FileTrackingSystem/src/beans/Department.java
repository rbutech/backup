package beans;

import java.util.HashSet;
import java.util.Set;


/**
 * Department entity. @author MyEclipse Persistence Tools
 */

public class Department  implements java.io.Serializable {


    // Fields    

     private Integer DId;
     private String dname;
     private String departmenthead;
     private Set fileLocations = new HashSet(0);
     private Set employees = new HashSet(0);


    // Constructors

    /** default constructor */
    public Department() {
    }

    
    /** full constructor */
    public Department(String dname, String departmenthead, Set fileLocations, Set employees) {
        this.dname = dname;
        this.departmenthead = departmenthead;
        this.fileLocations = fileLocations;
        this.employees = employees;
    }

   
    // Property accessors

    public Integer getDId() {
        return this.DId;
    }
    
    public void setDId(Integer DId) {
        this.DId = DId;
    }

    public String getDname() {
        return this.dname;
    }
    
    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getDepartmenthead() {
        return this.departmenthead;
    }
    
    public void setDepartmenthead(String departmenthead) {
        this.departmenthead = departmenthead;
    }

    public Set getFileLocations() {
        return this.fileLocations;
    }
    
    public void setFileLocations(Set fileLocations) {
        this.fileLocations = fileLocations;
    }

    public Set getEmployees() {
        return this.employees;
    }
    
    public void setEmployees(Set employees) {
        this.employees = employees;
    }
   








}