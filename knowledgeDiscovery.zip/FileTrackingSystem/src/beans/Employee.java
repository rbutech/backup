package beans;

import java.util.Date;


/**
 * Employee entity. @author MyEclipse Persistence Tools
 */

public class Employee  implements java.io.Serializable {


    // Fields    

     private Integer EId;
     private Department department;
     private String ename;
     private Integer esal;
     private Date jdate;


    // Constructors

    /** default constructor */
    public Employee() {
    }

    
    /** full constructor */
    public Employee(Department department, String ename, Integer esal, Date jdate) {
        this.department = department;
        this.ename = ename;
        this.esal = esal;
        this.jdate = jdate;
    }

   
    // Property accessors

    public Integer getEId() {
        return this.EId;
    }
    
    public void setEId(Integer EId) {
        this.EId = EId;
    }

    public Department getDepartment() {
        return this.department;
    }
    
    public void setDepartment(Department department) {
        this.department = department;
    }

    public String getEname() {
        return this.ename;
    }
    
    public void setEname(String ename) {
        this.ename = ename;
    }

    public Integer getEsal() {
        return this.esal;
    }
    
    public void setEsal(Integer esal) {
        this.esal = esal;
    }

    public Date getJdate() {
        return this.jdate;
    }
    
    public void setJdate(Date jdate) {
        this.jdate = jdate;
    }
   








}