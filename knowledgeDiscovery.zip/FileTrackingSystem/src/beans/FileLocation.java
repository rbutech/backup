package beans;



/**
 * FileLocation entity. @author MyEclipse Persistence Tools
 */

public class FileLocation  implements java.io.Serializable {


    // Fields    

     private Integer FId;
     private Department department;
     private Users users;
     private String filename;


    // Constructors

    /** default constructor */
    public FileLocation() {
    }

    
    /** full constructor */
    public FileLocation(Department department, Users users, String filename) {
        this.department = department;
        this.users = users;
        this.filename = filename;
    }

   
    // Property accessors

    public Integer getFId() {
        return this.FId;
    }
    
    public void setFId(Integer FId) {
        this.FId = FId;
    }

    public Department getDepartment() {
        return this.department;
    }
    
    public void setDepartment(Department department) {
        this.department = department;
    }

    public Users getUsers() {
        return this.users;
    }
    
    public void setUsers(Users users) {
        this.users = users;
    }

    public String getFilename() {
        return this.filename;
    }
    
    public void setFilename(String filename) {
        this.filename = filename;
    }
   








}