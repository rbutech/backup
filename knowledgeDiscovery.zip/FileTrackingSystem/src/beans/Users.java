package beans;



/**
 * Users entity. @author MyEclipse Persistence Tools
 */

public class Users  implements java.io.Serializable {


    // Fields    

     private Integer UId;
     private Employee employee;
     private String uname;
     private String pass;
     private String role;


    // Constructors

    /** default constructor */
    public Users() {
    }

    
    /** full constructor */
    public Users(Employee employee, String uname, String pass, String role) {
        this.employee = employee;
        this.uname = uname;
        this.pass = pass;
        this.role = role;
    }

   
    // Property accessors

    public Integer getUId() {
        return this.UId;
    }
    
    public void setUId(Integer UId) {
        this.UId = UId;
    }

    public Employee getEmployee() {
        return this.employee;
    }
    
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public String getUname() {
        return this.uname;
    }
    
    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getPass() {
        return this.pass;
    }
    
    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getRole() {
        return this.role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
   








}