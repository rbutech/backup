create table users(u_id number primary key not null,uname varchar2(30),pass varchar2(30),role varchar2(30));
create table department(d_id number primary key not null,dname varchar2(30),departmenthead varchar2(30));
create table employee(e_id number primary key not null,ename varchar2(30),esal number,jdate date,d_id number references department(d_id));
create table file_location(f_id number primary key not null,filename varchar2(30),d_id number references department(d_id));