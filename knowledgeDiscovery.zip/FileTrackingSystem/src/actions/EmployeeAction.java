package actions;

import java.util.Date;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import beans.Department;
import beans.Employee;

import com.opensymphony.xwork2.ActionSupport;

public class EmployeeAction extends ActionSupport{
	
	private String name;
	private int sal;
	private Date jdate;
	private String role;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public Date getJdate() {
		return jdate;
	}
	public void setJdate(Date jdate) {
		this.jdate = jdate;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

@Override
public void validate() {
if(name.equals("")){addFieldError("name","field cant be empty")	;}
if(sal==0){addFieldError("sal","field cant be empty")	;}
if(jdate==null){addFieldError("jdate","field cant be empty")	;}
if(role==null){addFieldError("role","field cant be empty")	;}
}
	
	
	@Override
	public String execute() throws Exception {

	SessionFactory sf=(SessionFactory)ServletActionContext.getServletContext().getAttribute("sf");		
	Session s=sf.openSession();
	Transaction t=s.beginTransaction();	
Query q=s.createQuery("From Department where dname='"+role+"'");
	List<Department> list=q.list();
	Department d=list.get(0);
	
	
	Employee emp=new  Employee(d, name,sal, jdate);
	s.save(emp);
	t.commit();
	addFieldError("name","SUCCESS");
return "success";	
	}

}
