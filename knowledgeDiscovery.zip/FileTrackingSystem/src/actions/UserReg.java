package actions;
import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import beans.Users;

import com.opensymphony.xwork2.ActionSupport;

public class UserReg extends ActionSupport{
	private String name;
	private String uname;
	private String pass;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	@Override
	public void validate() {
	if(name.equals("")){
		addFieldError("name","name field cant be null");
			}
	if(uname.equals("")){
		addFieldError("uname","username field cant be null");
			}
	if(pass.equals("")){
		addFieldError("pass","password field cant be null");
			}
	}
	
	@Override
	public String execute() throws Exception {
	HttpServletRequest req=ServletActionContext.getRequest();
		SessionFactory sf=(SessionFactory)req.getSession().getServletContext().getAttribute("sf");
		Session s=sf.openSession();		Transaction t=s.beginTransaction();
		Users u=new Users(null,uname,pass,"client");
		s.save(u);
		t.commit();

	return "regsucecss";	
		
	}
	
}