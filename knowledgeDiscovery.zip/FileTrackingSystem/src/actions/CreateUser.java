package actions;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import beans.Employee;
import beans.Users;

import com.opensymphony.xwork2.ActionSupport;

public class CreateUser extends ActionSupport {
	private String ename;
	private String uname;
	private String pass;
	private String cpass;
	private String role;
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getCpass() {
		return cpass;
	}
	public void setCpass(String cpass) {
		this.cpass = cpass;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public void validate() {
		if(ename.equals("")){
			addFieldError("ename","enter employee name");
					}
	if(uname.equals("")){
		addFieldError("uname","enter username");
	}
	if(pass.equals("")){
		addFieldError("pass","enter password");
	}
	if(cpass.equals("")){
		addFieldError("cpass","enter password");
	}
	if(!cpass.equals(pass)){
		addFieldError("cpass","enter matching password");
	}
	
	
	}
	
	@Override
	public String execute() throws Exception {
	
	SessionFactory sf=(SessionFactory)ServletActionContext.getServletContext().getAttribute("sf");
	Session s=sf.openSession();
	Transaction t=s.beginTransaction();
Query q=s.createQuery("From Employee where ename='"+ename+"'");
List<Employee> list=	q.list();
	Employee e=list.get(0);
Users u=new Users(e,uname,pass,role);
s.save(u);
t.commit();
addFieldError("uname","SUCCESS");
return "success";
	}
	

}
