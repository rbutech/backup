package actions;

import org.apache.struts2.ServletActionContext;
import org.hibernate.SessionFactory;

import Dao.DepartmentDao;
import Dao.DepartmentHibernateDao;

import beans.Department;

import com.opensymphony.xwork2.ActionSupport;

public class CreateDepartment extends ActionSupport {

private String  dname;
private String dhead;
public String getDname() {
	return dname;
}
public void setDname(String dname) {
	this.dname = dname;
}
public String getDhead() {
	return dhead;
}
public void setDhead(String dhead) {
	this.dhead = dhead;
}


@Override
	public void validate() {
		
	if(dname.equals("")){	addFieldError("dname","department name cant be empty");	}
	if(dhead.equals("")){addFieldError("dhead","department Head cant be empty");	}
	
	}

@Override
	public String execute() throws Exception {
	
	DepartmentDao d=new DepartmentHibernateDao((SessionFactory)ServletActionContext.getServletContext().getAttribute("sf"));
	Department dep=new Department(dname, dhead,null,null);
	addFieldError("dname","SUCECSS");
	return d.save(dep);
	}

}
