package actions;

import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import beans.Users;

import com.opensymphony.xwork2.ActionSupport;

public class Login extends ActionSupport {

private String uname;
private String pass;
private String role;
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}

@Override
	public void validate() {
	if(uname.equals("")){	addFieldError("uname", "username field cant be empty");	}
	if(pass.equals("")){addFieldError("pass", " password field cant be empty");}
	//if(role.equals("")){ addFieldError("role", "role field cant be empty");}
									}
@Override
	public String execute() throws Exception {
	HttpServletRequest req=ServletActionContext.getRequest();
	String msg=null;
	if(uname.equals("admin")&&pass.equals("admin")&&role.equals("admin")){
		msg="adminsuccess";
		
	}
if(role.equals("clerk")||role.equals("deputy secretary")||role.equals("additional secretary")||role.equals("secretary")||role.equals("ministry")){
SessionFactory sf=(SessionFactory)req.getSession().getServletContext().getAttribute("sf");
Session s=sf.openSession();
Connection con=	s.connection();
int i=con.createStatement().executeUpdate("select * from users  where UNAME='"+uname+"' and pass='"+pass+"' and role='"+role+"'");
if(i!=0){
	msg="rolessuccess";
}
}
else{
	SessionFactory sf=(SessionFactory)req.getSession().getServletContext().getAttribute("sf");
	Session s=sf.openSession();
	Connection con=	s.connection();
	System.out.println("SUCECSS...");
Query q=s.createQuery("From users  UNAME='"+uname+"' and pass='"+pass+"' and role='"+role+"'");
	List<Users> list=q.list();
	for(Users u:list){
		req.getSession().setAttribute("ua",u);
		
	}
	
	
	int i=con.createStatement().executeUpdate("select * from users  where UNAME='"+uname+"' and pass='"+pass+"' and role='"+role+"'");
	if(i!=0){
		msg="userssuccess";
	}	
	
}


return msg;
}

}
