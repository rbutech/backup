import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class MyListner implements ServletContextListener {
	SessionFactory sf;
	public void contextInitialized(ServletContextEvent se) {
	
		Configuration cfg=new Configuration();
		cfg.configure();
		sf=cfg.buildSessionFactory();
		se.getServletContext().setAttribute("sf",sf);
		System.out.println("FTS:");
		System.out.println(sf);
	
	}
	public void contextDestroyed(ServletContextEvent se) {
		sf.close();

			}



}
