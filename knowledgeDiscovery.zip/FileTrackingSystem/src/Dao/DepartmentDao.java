package Dao;

import org.hibernate.SessionFactory;

import beans.Department;

public interface DepartmentDao {
	
		public String save(Department d);	
		public String update(Department d);
		public String delete(Department d);	
		public Department select(Department d);
		public Department[] selectAll();
}
