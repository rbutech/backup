package Dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import beans.Department;

public class DepartmentHibernateDao implements DepartmentDao {
	
	private SessionFactory sf;
		
	public DepartmentHibernateDao(SessionFactory sf) {
		this.sf = sf;
		}

	public String delete(Department d) {
		
		return null;
	}

	public String save(Department d) {
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		t.begin();
		s.save(d);
		t.commit();
		
		return "dsuccess";
	}

	public Department select(Department d) {
		
		return null;
	}

	public Department[] selectAll() {
		
		return null;
	}

	public String update(Department d) {
		// TODO Auto-generated method stub
		return null;
	}

}
